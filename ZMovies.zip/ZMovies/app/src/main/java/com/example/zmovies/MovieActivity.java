package com.example.zmovies;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MovieActivity extends AppCompatActivity {
    TextView movieTitle,movieYear,movieRuntime,movieGenre,movieDirector,moviePlot;
    ImageView img;
    Button btnGravar;
    String filmeSelec;
    Movie movie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie);

        movieTitle = (TextView) findViewById(R.id.movieTitle);
        movieYear = (TextView) findViewById(R.id.movieYear);
        movieRuntime = (TextView) findViewById(R.id.movieRuntime);
        movieGenre = (TextView) findViewById(R.id.movieGenre);
        movieDirector = (TextView) findViewById(R.id.movieDirector);
        moviePlot = (TextView) findViewById(R.id.moviePlot);
        img = (ImageView) findViewById(R.id.imgPos);
        btnGravar = (Button) findViewById(R.id.btnGravar);

        Intent i = getIntent();
        filmeSelec = i.getStringExtra("filme");
        String url = filmeSelec.replace(" ", "%20");

        new GetJSONTask().execute("http://www.omdbapi.com/?t=" + url + "&apikey=9214999b");
    }

    private class GetJSONTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {

            try {
                return request(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                String poster = jsonObject.getString("Poster");
                String title = jsonObject.getString("Title");
                movieTitle.setText(jsonObject.getString("Title"));
                movieYear.setText(jsonObject.getString("Year"));
                movieRuntime.setText(jsonObject.getString("Runtime"));
                movieGenre.setText(jsonObject.getString("Genre"));
                movieDirector.setText(jsonObject.getString("Director"));
                moviePlot.setText(jsonObject.getString("Plot"));

                movie = new Movie();
                movie.setTitle(title);
                movie.setPoster(poster);
                movie.setYear(jsonObject.getString("Year"));
                movie.setRuntime(jsonObject.getString("Runtime"));
                movie.setGenre(jsonObject.getString("Genre"));
                movie.setPlot(jsonObject.getString("Plot"));
                Picasso.with(MovieActivity.this).load(poster).into(img);

                btnGravar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MovieDatabase db = new MovieDatabase(MovieActivity.this);
                        db.addFilmes(movie);
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public String request(String uri) throws IOException {
            StringBuilder sb = new StringBuilder();

            URL url = new URL(uri);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bin = new BufferedReader(new InputStreamReader(in));

                String inputLine;
                while ((inputLine = bin.readLine()) != null) {
                    sb.append(inputLine);
                }
            } finally {

                urlConnection.disconnect();
            }
            return sb.toString();
        }
    }


}