package com.example.zmovies;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class MovieAdapter extends BaseAdapter {
    private final List<Movie> movies;
    private final Activity act;

    public MovieAdapter(List<Movie> movies, Activity act) {
        this.movies = movies;
        this.act = act;
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int position) {
        return movies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = act.getLayoutInflater().inflate(R.layout.custom_listview, parent, false);

        Movie curso = movies.get(position);
        ImageView imagem = (ImageView)view.findViewById(R.id.imgPoster);
        Picasso.with(act).load(curso.getPoster()).into(imagem);

        TextView nome = (TextView)
                view.findViewById(R.id.title);

        nome.setText(curso.getTitle());



        return view;
    }
}