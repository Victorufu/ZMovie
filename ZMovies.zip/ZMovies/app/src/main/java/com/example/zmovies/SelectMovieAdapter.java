package com.example.zmovies;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;

public class SelectMovieAdapter extends BaseAdapter {
    private final List<Movie> movies;
    private final Activity act;

    public SelectMovieAdapter(List<Movie> movies, Activity act) {
        this.movies = movies;
        this.act = act;
    }

    @Override
    public int getCount() {
        return movies.size();
    }

    @Override
    public Object getItem(int position) {
        return movies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = act.getLayoutInflater().inflate(R.layout.custom_select_listview, parent, false);

        Movie movies = this.movies.get(position);

        TextView nome = (TextView)   view.findViewById(R.id.select_title);
        TextView year = (TextView)   view.findViewById(R.id.select_year);
        TextView runtime = (TextView)   view.findViewById(R.id.select_runtime);
        TextView genre = (TextView)   view.findViewById(R.id.select_genre);
        TextView plot = (TextView)   view.findViewById(R.id.select_plot);

        nome.setText(movies.getTitle());
        year.setText(movies.getYear());
        runtime.setText(movies.getRuntime());
        genre.setText(movies.getGenre());
        plot.setText(movies.getPlot());

        return view;
    }
}

