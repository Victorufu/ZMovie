package com.example.zmovies;


import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listaDeMovies;
    ArrayList<Movie> listdata = new ArrayList<Movie>();
    TextView textView;
    ImageView imageView;
    Button buscar,btnselectmovies;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.filme);
        imageView = (ImageView) findViewById(R.id.imageView);
        listaDeMovies = (ListView) findViewById(R.id.listView);
        buscar = (Button) findViewById(R.id.button);
        btnselectmovies=(Button)findViewById(R.id.btnselectmovies);
        editText = (EditText) findViewById(R.id.editText);
        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new JSONAsynTask().execute("http://www.omdbapi.com/?s=" + editText.getText() + "&page=1&apikey=9214999b");
                listdata.clear();
            }
        });
       btnselectmovies.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent ( MainActivity.this, SelectMovieActivity.class );
               startActivity(intent);
           }
       });
    }

    private class JSONAsynTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {
            try {
                return request(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve data. URL may be invalid.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject JOBJECT = new JSONObject(result);
                JSONArray array = JOBJECT.getJSONArray("Search");
                JSONObject home_idx_1 = array.getJSONObject(8);
                String image = home_idx_1.getString("Poster");
                String title = home_idx_1.getString("Title");

                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        Movie movie = new Movie();
                        movie.setTitle(jsonObject.getString("Title"));
                        movie.setPoster(jsonObject.getString("Poster"));
                        movie.setYear(jsonObject.getString("Year"));
                        listdata.add(movie);
                    }
                }

                MovieAdapter adapter = new MovieAdapter(listdata, MainActivity.this);

                listaDeMovies.setAdapter(adapter);
                listaDeMovies.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        TextView titleMovie = (TextView) view.findViewById(R.id.title);
                        Toast.makeText(parent.getContext(), titleMovie.getText().toString(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                        intent.putExtra("filme", titleMovie.getText().toString());
                        startActivity(intent);
                        //  finish();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public String request(String uri) throws IOException {
        StringBuilder sb = new StringBuilder();

        URL url = new URL(uri);
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader bin = new BufferedReader(new InputStreamReader(in));
            // temporary string to hold each line read from the reader.
            String inputLine;
            while ((inputLine = bin.readLine()) != null) {
                sb.append(inputLine);
            }
        } finally {
            // regardless of success or failure, we will disconnect from the URLConnection.
            urlConnection.disconnect();
        }
        return sb.toString();
    }
}
