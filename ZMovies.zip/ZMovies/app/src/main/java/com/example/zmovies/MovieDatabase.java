package com.example.zmovies;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MovieDatabase extends SQLiteOpenHelper {
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Nome do banco
    private static final String DATABASE_NAME = "filmesdb";
    // Tabela filme
    private static final String TABLE_FILME = "filmes";
    //Colunas da tabela filmes
    private static final String KEY_TITLE = "title";
    private static final String KEY_POSTER = "poster";
    private static final String KEY_YEAR = "year";
    private static final String KEY_RUNTIME = "runtime";
    private static final String KEY_GENRE = "genre";
    private static final String KEY_DIRECTOR = "director";
    private static final String KEY_PLOT = "plot";
    private static final String KEY_LANGUAGE = "language";
    private static final String KEY_BOX = "box";


    public MovieDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Criar tabelas
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_FILMES = "CREATE TABLE " + TABLE_FILME + "("
                        + KEY_TITLE + " TEXT,"
                        + KEY_POSTER + " TEXT,"
                        + KEY_YEAR + " TEXT,"
                        + KEY_RUNTIME + " TEXT,"
                        + KEY_GENRE + " TEXT,"
                        + KEY_DIRECTOR + " TEXT,"
                        + KEY_PLOT + " TEXT,"
                        + KEY_LANGUAGE + " TEXT,"
                        + KEY_BOX + " TEXT"+ ")";
        db.execSQL(CREATE_TABLE_FILMES);
    }


    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FILME);
        // Create tables again
        onCreate(db);
    }

    //Operações de CRUD
    public void addFilmes(Movie filmes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, filmes.getTitle());
        values.put(KEY_POSTER, filmes.getPoster());
        values.put(KEY_YEAR, filmes.getYear());
        values.put(KEY_RUNTIME, filmes.getRuntime());
        values.put(KEY_GENRE, filmes.getGenre());
        values.put(KEY_DIRECTOR, filmes.getDirector());
        values.put(KEY_PLOT, filmes.getPlot());
        values.put(KEY_LANGUAGE, filmes.getLanguage());
        values.put(KEY_BOX, filmes.getBoxOffice());
        db.insert(TABLE_FILME, null, values);
        Log.i("foi",filmes.getTitle());
        db.close();
    }

    //Listar todos os filmes
    public List<Movie> getAllFilmes() {
        List<Movie> filmesList = new ArrayList<Movie>();
        String selectQuery = "SELECT  * FROM filmes ORDER BY title";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Movie filmes = new Movie();
                filmes.setTitle(cursor.getString(0));
                filmes.setPoster(cursor.getString(1));
                filmes.setYear(cursor.getString(2));
                filmes.setRuntime(cursor.getString(3));
                filmes.setGenre(cursor.getString(4));
                filmes.setPlot(cursor.getString(5));
                filmesList.add(filmes);
            } while (cursor.moveToNext());
        }
        db.close();
        return filmesList;
    }
}

