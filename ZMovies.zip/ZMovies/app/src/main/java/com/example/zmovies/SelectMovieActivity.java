package com.example.zmovies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class SelectMovieActivity extends AppCompatActivity {

    ListView select_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_movie);
        select_list =(ListView)findViewById(R.id.select_list);
        MovieDatabase dataBase = new MovieDatabase(this);
        List<Movie> filmes = dataBase.getAllFilmes();

        SelectMovieAdapter adapter =  new SelectMovieAdapter(filmes, SelectMovieActivity.this);

        select_list.setAdapter(adapter);
    }
}
